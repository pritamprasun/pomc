<?php
/*
 * @file
 *
 *
 * Things that are not well documented:
 *  - HeartbeatActivity.additions.comment_open_override is a variable which can be set to
 *  TRUE  when you want  comments  to start in "open" state.
 */


